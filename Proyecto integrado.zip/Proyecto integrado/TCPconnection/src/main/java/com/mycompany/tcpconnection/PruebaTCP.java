/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tcpconnection;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import static java.lang.System.in;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author AlvaroCabañasSánchez
 */
public class PruebaTCP {

    public static void main(String[] args) throws IOException {
        
        String serverName = "192.168.1.102";
        int serverPort = Integer.parseInt("8080");
        String message = "Soy el cliente y me he conectado correctamente!";
        Socket s = new Socket(serverName, serverPort);
        try ( //      espera que el servidor acepte
            DataOutputStream dos = new DataOutputStream(s.getOutputStream())) {
            DataInputStream entrada = new DataInputStream(s.getInputStream());
            dos.writeChars(message);
            
            dataReceiver(entrada);
        
        }
    }
    
    public static void dataReceiver(DataInputStream _entrada) throws IOException{
        while(true)
        {
            
            String data = _entrada.readLine();
            System.out.println(data);
        }
    }
}
