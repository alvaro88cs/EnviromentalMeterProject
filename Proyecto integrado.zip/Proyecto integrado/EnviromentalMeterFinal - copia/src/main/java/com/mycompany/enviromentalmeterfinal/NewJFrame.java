/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.enviromentalmeterfinal;

import com.panamahitek.ArduinoException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import static java.time.Clock.system;
import java.util.Date;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Timer;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

/**
 *
 * @author AlvaroCabañasSánchez
 */
public final class NewJFrame extends javax.swing.JFrame {

    static int moduleCounter = 0;  //Contador de módulos conectados
    static int rotator = 0;        //Rotador de gráficas
    static int identifier = 0;     // Identificador de módulo

    static int luminosity = 0;     // Tanto por ciento (%)
    static int numPerson = 0;          // Personas/Habitación
    static int preasure = 0;       // Pascales (Pa)
    static int fire = 0;           // false: no hay incendio
    static String flame = "No hay incendio";

    static TimeSeries series1 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset1 = new TimeSeriesCollection(series1);

    static TimeSeries series2 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset2 = new TimeSeriesCollection(series2);

    static TimeSeries series3 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset3 = new TimeSeriesCollection(series3);

    static TimeSeries series4 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset4 = new TimeSeriesCollection(series4);

    Timer shiftClock = new Timer(60000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent arg0) {

            series1.clear();
            series2.clear();
            series3.clear();
            series4.clear();

            if (rotator < moduleCounter) {
                rotator++;
            } else {
                rotator = 0;
            }

        }
    });

    /**
     * Creates new form NewJFrame
     *
     * @throws java.lang.InterruptedException
     * @throws com.panamahitek.ArduinoException
     * @throws java.io.IOException
     * @throws java.lang.ClassNotFoundException
     */
    public NewJFrame() throws InterruptedException, ArduinoException, IOException, ClassNotFoundException {
        initComponents();
        this.setExtendedState(NewJFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        shiftClock.start();

        series1.add(new Second(new Date()), 0);
        series2.add(new Second(new Date()), 0);
        series3.add(new Second(new Date()), 0);
        series4.add(new Second(new Date()), 0);

        dataset1.addSeries(series1);
        dataset2.addSeries(series2);
        dataset3.addSeries(series3);
        dataset4.addSeries(series4);

        try {
            humidityChartInsert(series1, dataset1);
            temperatureChartInsert(series2, dataset2);
            dioxideChartInsert(series3, dataset3);
            noiseChartInsert(series4, dataset4);
        } catch (InterruptedException ex) {
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void JavaTCPconnection(String _serverName, String _serverPort, String _message) throws IOException {

        int[] temperature;    // Grados (º)
        int[] humidity;       // Tanto por ciento (%)
        int[] noise;          // Decibelios (dB)
        int[] dioxide;        // Partes por millon (ppm)

        humidity = new int[100];
        temperature = new int[100];
        dioxide = new int[100];
        noise = new int[100];

        String serverName = _serverName;
        int serverPort = Integer.parseInt(_serverPort);
        String message = _message;
        Socket s = new Socket(serverName, serverPort);
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        DataInputStream entrada = new DataInputStream(s.getInputStream());
        dos.writeChars(message);

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Timer timer = new Timer(4000, (ActionEvent arg0) -> {
                    int i = 0;
                    String data = null;
                    String[] receivedData;

                    try {
                        data = entrada.readLine();
                    } catch (IOException ex) {
                        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    receivedData = data.split(",");

                    identifier = Integer.parseInt(receivedData[0]);
                    humidity[i] = Integer.parseInt(receivedData[1]);
                    temperature[i] = Integer.parseInt(receivedData[2]);
                    dioxide[i] = Integer.parseInt(receivedData[3]);
                    noise[i] = Integer.parseInt(receivedData[4]);
                    preasure = Integer.parseInt(receivedData[5]);
                    luminosity = Integer.parseInt(receivedData[6]);
                    numPerson = Integer.parseInt(receivedData[7]);
                    fire = Integer.parseInt(receivedData[8]);

                    if (identifier == rotator) {

                        series1.add(new Second(new Date()), humidity[i]);
                        series2.add(new Second(new Date()), temperature[i]);
                        series3.add(new Second(new Date()), dioxide[i]);
                        series4.add(new Second(new Date()), noise[i]);

                        dataset1.addSeries(series1);
                        dataset2.addSeries(series2);
                        dataset3.addSeries(series3);
                        dataset4.addSeries(series4);

                        parametersInsert(
                                humidity[i],
                                temperature[i],
                                dioxide[i],
                                noise[i],
                                preasure,
                                luminosity,
                                numPerson,
                                fire,
                                flame
                        );
                    }
                    if (i < 100) {
                        i++;
                    } else {
                        i = 0;
                    }
                });
                timer.start();
            }
        });
    }

    public static void humidityChartInsert(TimeSeries _series, TimeSeriesCollection _dataset) throws InterruptedException {

        _dataset.addSeries(_series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Humedad Interior",
                "Tiempo (h)",
                "Humedad (%)",
                _dataset,
                false,
                false,
                false
        );
        // Mostramos la grafica dentro del HumidityPanel
        graphicpainter(chart, HumidityPanel);
    }

    public static void temperatureChartInsert(TimeSeries _series, TimeSeriesCollection _dataset) throws InterruptedException {

        _dataset.addSeries(_series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Temperatura Interior",
                "Tiempo (h)",
                "Grados (º)",
                _dataset,
                false,
                false,
                false
        );
        // Mostramos la grafica dentro del TemperaturePanel
        graphicpainter(chart, TemperaturePanel);
    }

    public static void dioxideChartInsert(TimeSeries _series, TimeSeriesCollection _dataset) throws InterruptedException {

        _dataset.addSeries(_series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Dioxido Interior",
                "Tiempo (h)",
                "Dioxido (ppm)",
                _dataset,
                false,
                false,
                false
        );
        // Mostramos la grafica dentro del DioxidePanel
        graphicpainter(chart, DioxidePanel);
    }

    public static void noiseChartInsert(TimeSeries _series, TimeSeriesCollection _dataset) throws InterruptedException {

        _dataset.addSeries(_series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Ruido Interior",
                "Tiempo (h)",
                "Decibelios (dB)",
                _dataset,
                false,
                false,
                false
        );
        // Mostramos la grafica dentro del NoisePanel
        graphicpainter(chart, NoisePanel);
    }

    public static void parametersInsert(int _humidity, int _temperature, int _dioxide, int _noise, int _preasure, int _luminosity, int _numPerson, int _fire, String flame) {

        if (_fire == 1) {
            flame = "Alerta de incendio";
        }
        processingParametersTable.setValueAt(_humidity, 0, 1);
        processingParametersTable.setValueAt(_temperature, 1, 1);
        processingParametersTable.setValueAt(_dioxide, 2, 1);
        processingParametersTable.setValueAt(_noise, 3, 1);
        processingParametersTable.setValueAt(_preasure, 4, 1);
        processingParametersTable.setValueAt(_luminosity, 5, 1);
        processingParametersTable.setValueAt(_numPerson, 6, 1);
        processingParametersTable.setValueAt(flame, 7, 1);

    }

    public static void graphicpainter(JFreeChart _chart, javax.swing.JPanel auxPanel) {
        // Mostramos la grafica dentro de los Paneles
        ChartPanel panel = new ChartPanel(_chart);
        auxPanel.setLayout(new java.awt.BorderLayout());
        auxPanel.add(panel);
        auxPanel.validate();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        leftPanel = new javax.swing.JPanel();
        GraphsPanel = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        HumidityPanel = new javax.swing.JPanel();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        TemperaturePanel = new javax.swing.JPanel();
        jLayeredPane3 = new javax.swing.JLayeredPane();
        DioxidePanel = new javax.swing.JPanel();
        jLayeredPane4 = new javax.swing.JLayeredPane();
        NoisePanel = new javax.swing.JPanel();
        rightPanel = new javax.swing.JPanel();
        TablePanel = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        parametersPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        processingParametersTable = new javax.swing.JTable();
        DataPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        IP = new javax.swing.JTextField();
        Port = new javax.swing.JTextField();
        Name = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        leftPanel.setMaximumSize(new java.awt.Dimension(252, 149));
        leftPanel.setLayout(new java.awt.GridBagLayout());

        GraphsPanel.setLayout(new java.awt.GridBagLayout());

        jLayeredPane1.setBorder(javax.swing.BorderFactory.createTitledBorder("Humedad"));
        jLayeredPane1.setLayout(new java.awt.GridBagLayout());

        HumidityPanel.setMaximumSize(new java.awt.Dimension(640, 420));
        HumidityPanel.setMinimumSize(new java.awt.Dimension(640, 420));
        HumidityPanel.setPreferredSize(new java.awt.Dimension(640, 420));
        HumidityPanel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jLayeredPane1.add(HumidityPanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 1.0;
        GraphsPanel.add(jLayeredPane1, gridBagConstraints);

        jLayeredPane2.setBorder(javax.swing.BorderFactory.createTitledBorder("Temperatura"));
        jLayeredPane2.setLayout(new java.awt.GridBagLayout());

        TemperaturePanel.setMaximumSize(new java.awt.Dimension(640, 420));
        TemperaturePanel.setMinimumSize(new java.awt.Dimension(640, 420));
        TemperaturePanel.setPreferredSize(new java.awt.Dimension(640, 420));
        TemperaturePanel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jLayeredPane2.add(TemperaturePanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 1.0;
        GraphsPanel.add(jLayeredPane2, gridBagConstraints);

        jLayeredPane3.setBorder(javax.swing.BorderFactory.createTitledBorder("Dioxido Carbono"));
        jLayeredPane3.setLayout(new java.awt.GridBagLayout());

        DioxidePanel.setMaximumSize(new java.awt.Dimension(640, 420));
        DioxidePanel.setMinimumSize(new java.awt.Dimension(640, 420));
        DioxidePanel.setPreferredSize(new java.awt.Dimension(640, 420));
        DioxidePanel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jLayeredPane3.add(DioxidePanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 1.0;
        GraphsPanel.add(jLayeredPane3, gridBagConstraints);

        jLayeredPane4.setBorder(javax.swing.BorderFactory.createTitledBorder("Ruido"));
        jLayeredPane4.setLayout(new java.awt.GridBagLayout());

        NoisePanel.setMaximumSize(new java.awt.Dimension(640, 420));
        NoisePanel.setMinimumSize(new java.awt.Dimension(640, 420));
        NoisePanel.setPreferredSize(new java.awt.Dimension(640, 420));
        NoisePanel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jLayeredPane4.add(NoisePanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 1.0;
        GraphsPanel.add(jLayeredPane4, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.9;
        leftPanel.add(GraphsPanel, gridBagConstraints);

        rightPanel.setMaximumSize(new java.awt.Dimension(450, 100));
        rightPanel.setLayout(new java.awt.GridBagLayout());

        TablePanel.setLayout(new java.awt.GridBagLayout());

        jPanel4.setLayout(new java.awt.GridBagLayout());

        parametersPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Parámetros"));
        parametersPanel.setLayout(new java.awt.GridBagLayout());

        jScrollPane1.setMinimumSize(new java.awt.Dimension(300, 300));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(122, 122));

        processingParametersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"HUMEDAD", null},
                {"TEMPERATURA", null},
                {"DIOXIDO CARBONO", null},
                {"NIVEL RUIDO", null},
                {"PRESIÓN ATM.", null},
                {"LUMINOSIDAD", null},
                {"NÚMERO PERSONAS", null},
                {"INCENDIO", null},
                {null, null},
                {"SALA MOSTRADA", null},
                {null, null},
                {"NOMBRE", "ÁLVARO"},
                {"APELLIDO 1", "CABAÑAS"},
                {"APELLIDO 2", "SÁNCHEZ"},
                {"CURSO", "2 º STI"}
            },
            new String [] {
                "Parámetro", "Valor"
            }
        ));
        processingParametersTable.setRowHeight(40);
        processingParametersTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(processingParametersTable);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        parametersPanel.add(jScrollPane1, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.2;
        jPanel4.add(parametersPanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.3;
        TablePanel.add(jPanel4, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.8;
        rightPanel.add(TablePanel, gridBagConstraints);

        DataPanel.setMaximumSize(new java.awt.Dimension(450, 100));
        DataPanel.setMinimumSize(new java.awt.Dimension(450, 100));
        DataPanel.setLayout(new java.awt.GridBagLayout());

        jLabel1.setText("Añadir Módulo:");
        jLabel1.setToolTipText("");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        DataPanel.add(jLabel1, gridBagConstraints);

        IP.setText("Insert IP");
        IP.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        IP.setMaximumSize(new java.awt.Dimension(30, 24));
        IP.setMinimumSize(new java.awt.Dimension(30, 24));
        IP.setName(""); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 5);
        DataPanel.add(IP, gridBagConstraints);

        Port.setText("Insert Port");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 5);
        DataPanel.add(Port, gridBagConstraints);

        Name.setText("Name");
        Name.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Name.setMaximumSize(new java.awt.Dimension(30, 24));
        Name.setMinimumSize(new java.awt.Dimension(30, 24));
        Name.setName(""); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 5);
        DataPanel.add(Name, gridBagConstraints);

        jButton1.setText("Accept");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        DataPanel.add(jButton1, new java.awt.GridBagConstraints());

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.05;
        rightPanel.add(DataPanel, gridBagConstraints);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1515, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(leftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1147, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 368, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addGap(0, 1149, Short.MAX_VALUE)
                    .addComponent(rightPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 765, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(leftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 765, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(rightPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 765, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String ip, port, name;

        ip = IP.getText();
        port = Port.getText();
        name = Name.getText();

        moduleCounter++;

        series1.clear();
        series2.clear();
        series3.clear();
        series4.clear();

        try {
            NewJFrame.JavaTCPconnection(ip, port, name);
        } catch (IOException ex) {
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String args[]) throws IOException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                //Inicia la interfaz gráfica
                new NewJFrame().setVisible(true);

                //Inicia la conexión TCP/IP
//                NewJFrame.JavaTCPconnection("172.26.240.240", "8080", "Soy el cliente y me he conectado correctamente!");
            } catch (InterruptedException | ArduinoException | IOException | ClassNotFoundException ex) {
                Logger.getLogger(NewJFrame.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel DataPanel;
    private static javax.swing.JPanel DioxidePanel;
    private javax.swing.JPanel GraphsPanel;
    private static javax.swing.JPanel HumidityPanel;
    private javax.swing.JTextField IP;
    private javax.swing.JTextField Name;
    private static javax.swing.JPanel NoisePanel;
    private javax.swing.JTextField Port;
    private javax.swing.JPanel TablePanel;
    private static javax.swing.JPanel TemperaturePanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JLayeredPane jLayeredPane3;
    private javax.swing.JLayeredPane jLayeredPane4;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JPanel parametersPanel;
    private static javax.swing.JTable processingParametersTable;
    private javax.swing.JPanel rightPanel;
    // End of variables declaration//GEN-END:variables
}
