# Curso Arduino desde cero en Español

Código fuente de programas vistos en el Curso de Arduino desde Cero en Español.

Canal de Yotube: https://www.youtube.com/c/BitwiseAr


- Ingresá a la carpeta del número de capítulo que desees descargar el código de los programas.
- Cada programa se encuentra en formato .txt de manera que podrás hacer clic y verlo en el navegador.
- Es importante que desactives la traducción automática de Inglés a Español ya que sino el código será traducido y por ende inutilizable.
- Podrás seleccionar el código, copiarlo y pegarlo en el editor del IDE.
- Podrás descargar el archivo de texto y luego abrirlo de forma local en tu computadora.

En el canal de YouTube arriba mencionado se encuentra la explicación paso a paso sobre el principio de funcionamiento del dispositivo o sensor, el circuito de conexión, esquemáticos y diagramas, como asi también enlaces a librerías necesarias dependiendo el caso.

### ¡ Saludos !
