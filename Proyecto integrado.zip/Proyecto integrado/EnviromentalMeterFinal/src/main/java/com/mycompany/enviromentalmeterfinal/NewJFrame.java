/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.enviromentalmeterfinal;

import com.panamahitek.ArduinoException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import static java.time.Clock.system;
import java.util.Date;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Timer;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

/**
 *
 * @author AlvaroCabañasSánchez
 */
public final class NewJFrame extends javax.swing.JFrame {

    static int identifier = 0;     // Identificador de módulo
    static int[] temperature;    // Grados (º)
    static int[] humidity;       // Tanto por ciento (%)
    static int[] noise;          // Decibelios (dB)
    static int[] luminosity;     // Tanto por ciento (%)
    static int[] dioxide;        // Partes por millon (ppm)
    static int[] numPerson;          // Personas/Habitación
    static int[] preasure;       // Pascales (Pa)
    static int[] fire;           // false: no hay incendio
    static String flame = "No hay incendio";

    static boolean newModule = false;
    static int counter = 0;

    static TimeSeries series1 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset1 = new TimeSeriesCollection(series1);

    static TimeSeries series2 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset2 = new TimeSeriesCollection(series2);

    static TimeSeries series3 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset3 = new TimeSeriesCollection(series3);

    static TimeSeries series4 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset4 = new TimeSeriesCollection(series4);

    static TimeSeries seriesaux1 = new TimeSeries("", Second.class);
    static TimeSeriesCollection datasetaux1 = new TimeSeriesCollection(seriesaux1);

    static TimeSeries seriesaux2 = new TimeSeries("", Second.class);
    static TimeSeriesCollection datasetaux2 = new TimeSeriesCollection(seriesaux2);

    static TimeSeries seriesaux3 = new TimeSeries("", Second.class);
    static TimeSeriesCollection datasetaux3 = new TimeSeriesCollection(seriesaux3);

    static TimeSeries seriesaux4 = new TimeSeries("", Second.class);
    static TimeSeriesCollection datasetaux4 = new TimeSeriesCollection(seriesaux4);

    static TimeSeries series5 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset5 = new TimeSeriesCollection(series5);

    static TimeSeries series6 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset6 = new TimeSeriesCollection(series6);

    static TimeSeries series7 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset7 = new TimeSeriesCollection(series7);

    static TimeSeries series8 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset8 = new TimeSeriesCollection(series8);

    static TimeSeries series9 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset9 = new TimeSeriesCollection(series9);

    static TimeSeries series10 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset10 = new TimeSeriesCollection(series10);

    static TimeSeries series11 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset11 = new TimeSeriesCollection(series11);

    static TimeSeries series12 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset12 = new TimeSeriesCollection(series12);

    static TimeSeries series13 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset13 = new TimeSeriesCollection(series13);

    static TimeSeries series14 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset14 = new TimeSeriesCollection(series14);

    static TimeSeries series15 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset15 = new TimeSeriesCollection(series15);

    static TimeSeries series16 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset16 = new TimeSeriesCollection(series16);

    static TimeSeries series17 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset17 = new TimeSeriesCollection(series17);

    static TimeSeries series18 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset18 = new TimeSeriesCollection(series18);

    static TimeSeries series19 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset19 = new TimeSeriesCollection(series19);

    static TimeSeries series20 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset20 = new TimeSeriesCollection(series20);

    static TimeSeries series21 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset21 = new TimeSeriesCollection(series21);

    static TimeSeries series22 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset22 = new TimeSeriesCollection(series22);

    static TimeSeries series23 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset23 = new TimeSeriesCollection(series23);

    static TimeSeries series24 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset24 = new TimeSeriesCollection(series24);

    static TimeSeries series25 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset25 = new TimeSeriesCollection(series25);

    static TimeSeries series26 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset26 = new TimeSeriesCollection(series26);

    static TimeSeries series27 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset27 = new TimeSeriesCollection(series27);

    static TimeSeries series28 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset28 = new TimeSeriesCollection(series28);

    static TimeSeries series29 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset29 = new TimeSeriesCollection(series29);

    static TimeSeries series30 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset30 = new TimeSeriesCollection(series30);

    static TimeSeries series31 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset31 = new TimeSeriesCollection(series31);

    static TimeSeries series32 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset32 = new TimeSeriesCollection(series32);

    static TimeSeries series33 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset33 = new TimeSeriesCollection(series33);

    static TimeSeries series34 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset34 = new TimeSeriesCollection(series34);

    static TimeSeries series35 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset35 = new TimeSeriesCollection(series35);

    static TimeSeries series36 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset36 = new TimeSeriesCollection(series36);

    static TimeSeries series37 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset37 = new TimeSeriesCollection(series37);

    static TimeSeries series38 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset38 = new TimeSeriesCollection(series38);

    static TimeSeries series39 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset39 = new TimeSeriesCollection(series39);

    static TimeSeries series40 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset40 = new TimeSeriesCollection(series40);

    static TimeSeries series41 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset41 = new TimeSeriesCollection(series41);

    static TimeSeries series42 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset42 = new TimeSeriesCollection(series42);

    static TimeSeries series43 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset43 = new TimeSeriesCollection(series43);

    static TimeSeries series44 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset44 = new TimeSeriesCollection(series44);

    static TimeSeries series45 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset45 = new TimeSeriesCollection(series45);

    static TimeSeries series46 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset46 = new TimeSeriesCollection(series46);

    static TimeSeries series47 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset47 = new TimeSeriesCollection(series47);

    static TimeSeries series48 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset48 = new TimeSeriesCollection(series48);

    static TimeSeries series49 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset49 = new TimeSeriesCollection(series49);

    static TimeSeries series50 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset50 = new TimeSeriesCollection(series50);

    static TimeSeries series51 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset51 = new TimeSeriesCollection(series51);

    static TimeSeries series52 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset52 = new TimeSeriesCollection(series52);

    static TimeSeries series53 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset53 = new TimeSeriesCollection(series53);

    static TimeSeries series54 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset54 = new TimeSeriesCollection(series54);

    static TimeSeries series55 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset55 = new TimeSeriesCollection(series55);

    static TimeSeries series56 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset56 = new TimeSeriesCollection(series56);

    static TimeSeries series57 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset57 = new TimeSeriesCollection(series57);

    static TimeSeries series58 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset58 = new TimeSeriesCollection(series58);

    static TimeSeries series59 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset59 = new TimeSeriesCollection(series59);

    static TimeSeries series60 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset60 = new TimeSeriesCollection(series60);

    static TimeSeries series61 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset61 = new TimeSeriesCollection(series61);

    static TimeSeries series62 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset62 = new TimeSeriesCollection(series62);

    static TimeSeries series63 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset63 = new TimeSeriesCollection(series63);

    static TimeSeries series64 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset64 = new TimeSeriesCollection(series64);

    static TimeSeries series65 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset65 = new TimeSeriesCollection(series65);

    static TimeSeries series66 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset66 = new TimeSeriesCollection(series66);

    static TimeSeries series67 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset67 = new TimeSeriesCollection(series67);

    static TimeSeries series68 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset68 = new TimeSeriesCollection(series68);

    static TimeSeries series69 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset69 = new TimeSeriesCollection(series69);

    static TimeSeries series70 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset70 = new TimeSeriesCollection(series70);

    static TimeSeries series71 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset71 = new TimeSeriesCollection(series71);

    static TimeSeries series72 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset72 = new TimeSeriesCollection(series72);

    static TimeSeries series73 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset73 = new TimeSeriesCollection(series73);

    static TimeSeries series74 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset74 = new TimeSeriesCollection(series74);

    static TimeSeries series75 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset75 = new TimeSeriesCollection(series75);

    static TimeSeries series76 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset76 = new TimeSeriesCollection(series76);

    static TimeSeries series77 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset77 = new TimeSeriesCollection(series77);

    static TimeSeries series78 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset78 = new TimeSeriesCollection(series78);

    static TimeSeries series79 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset79 = new TimeSeriesCollection(series79);

    static TimeSeries series80 = new TimeSeries("", Second.class);
    static TimeSeriesCollection dataset80 = new TimeSeriesCollection(series80);

    Timer first = new Timer(4000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent arg0) {
            processingParametersTable.setValueAt(0, 9, 1);
            
            series1.add(new Second(new Date()), humidity[identifier]);
            series2.add(new Second(new Date()), temperature[identifier]);
            series3.add(new Second(new Date()), dioxide[identifier]);
            series4.add(new Second(new Date()), noise[identifier]);

            dataset1.addSeries(series1);
            dataset2.addSeries(series2);
            dataset3.addSeries(series3);
            dataset4.addSeries(series4);

            try {
                humidityChartInsert(series1, dataset1);
                temperatureChartInsert(series2, dataset2);
                dioxideChartInsert(series3, dataset3);
                noiseChartInsert(series4, dataset4);
            } catch (InterruptedException ex) {
                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
            }

            parametersInsert(
                    humidity[identifier],
                    temperature[identifier],
                    dioxide[identifier],
                    noise[identifier],
                    preasure[identifier],
                    luminosity[identifier],
                    numPerson[identifier],
                    fire[identifier]
            );
        }
    });

    /**
     * Creates new form NewJFrame
     *
     * @throws java.lang.InterruptedException
     * @throws com.panamahitek.ArduinoException
     * @throws java.io.IOException
     * @throws java.lang.ClassNotFoundException
     */
    public NewJFrame() throws InterruptedException, ArduinoException, IOException, ClassNotFoundException {
        initComponents();
        this.setExtendedState(NewJFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        humidity = new int[20];
        temperature = new int[20];
        noise = new int[20];
        luminosity = new int[20];
        dioxide = new int[20];
        preasure = new int[20];
        numPerson = new int[20];
        fire = new int[20];

        series1.add(new Second(new Date()), 0);
        series2.add(new Second(new Date()), 0);
        series3.add(new Second(new Date()), 0);
        series4.add(new Second(new Date()), 0);

        first.start();
    }

    public static void JavaTCPconnection(String _serverName, String _serverPort, String _message) throws IOException {

        String serverName = _serverName;
        int serverPort = Integer.parseInt(_serverPort);
        String message = _message;
        Socket s = new Socket(serverName, serverPort);
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        DataInputStream entrada = new DataInputStream(s.getInputStream());
        dos.writeChars(message);

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Timer time = new Timer(4000, (ActionEvent arg0) -> {
                    String data = null;
                    String[] receivedData;

                    try {
                        data = entrada.readLine();
                    } catch (IOException ex) {
                        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    receivedData = data.split(",");

                    identifier = Integer.parseInt(receivedData[0]);
                    humidity[identifier] = Integer.parseInt(receivedData[1]);
                    temperature[identifier] = Integer.parseInt(receivedData[2]);
                    dioxide[identifier] = Integer.parseInt(receivedData[3]);
                    noise[identifier] = Integer.parseInt(receivedData[4]);
                    preasure[identifier] = Integer.parseInt(receivedData[5]);
                    luminosity[identifier] = Integer.parseInt(receivedData[6]);
                    numPerson[identifier] = Integer.parseInt(receivedData[7]);
                    fire[identifier] = Integer.parseInt(receivedData[8]);

                    System.out.println(identifier);
                    System.out.println(humidity[identifier]);
                    System.out.println(temperature[identifier]);
                    System.out.println(dioxide[identifier]);
                    System.out.println(noise[identifier]);

                    switch (identifier) {
                        case 0:
                            series1.addOrUpdate(new Second(new Date()), humidity[identifier]);
                            series2.addOrUpdate(new Second(new Date()), temperature[identifier]);
                            series3.addOrUpdate(new Second(new Date()), dioxide[identifier]);
                            series4.addOrUpdate(new Second(new Date()), noise[identifier]);
//                            dataset1.addSeries(series1);
//                            dataset2.addSeries(series2);
//                            dataset3.addSeries(series3);
//                            dataset4.addSeries(series4);
                            break;
                        case 1:
                            series5.addOrUpdate(new Second(new Date()), humidity[identifier]);
                            series6.addOrUpdate(new Second(new Date()), temperature[identifier]);
                            series7.addOrUpdate(new Second(new Date()), dioxide[identifier]);
                            series8.addOrUpdate(new Second(new Date()), noise[identifier]);
//                            dataset5.addSeries(series5);
//                            dataset6.addSeries(series6);
//                            dataset7.addSeries(series7);
//                            dataset8.addSeries(series8);
                            break;
                        case 2:
                            series9.add(new Second(new Date()), humidity[identifier]);
                            series10.add(new Second(new Date()), temperature[identifier]);
                            series11.add(new Second(new Date()), dioxide[identifier]);
                            series12.add(new Second(new Date()), noise[identifier]);
                            dataset9.addSeries(series9);
                            dataset10.addSeries(series10);
                            dataset11.addSeries(series11);
                            dataset12.addSeries(series12);
                            break;
                        case 3:
                            series13.add(new Second(new Date()), humidity[identifier]);
                            series14.add(new Second(new Date()), temperature[identifier]);
                            series15.add(new Second(new Date()), dioxide[identifier]);
                            series16.add(new Second(new Date()), noise[identifier]);
                            dataset13.addSeries(series13);
                            dataset14.addSeries(series14);
                            dataset15.addSeries(series15);
                            dataset16.addSeries(series16);
                            break;
                        case 4:
                            series17.add(new Second(new Date()), humidity[identifier]);
                            series18.add(new Second(new Date()), temperature[identifier]);
                            series19.add(new Second(new Date()), dioxide[identifier]);
                            series20.add(new Second(new Date()), noise[identifier]);
                            dataset17.addSeries(series17);
                            dataset18.addSeries(series18);
                            dataset19.addSeries(series19);
                            dataset20.addSeries(series20);
                            break;
                        case 5:
                            series21.add(new Second(new Date()), humidity[identifier]);
                            series22.add(new Second(new Date()), temperature[identifier]);
                            series23.add(new Second(new Date()), dioxide[identifier]);
                            series24.add(new Second(new Date()), noise[identifier]);
                            dataset21.addSeries(series21);
                            dataset22.addSeries(series22);
                            dataset23.addSeries(series23);
                            dataset24.addSeries(series24);
                            break;
                        case 6:
                            series25.add(new Second(new Date()), humidity[identifier]);
                            series26.add(new Second(new Date()), temperature[identifier]);
                            series27.add(new Second(new Date()), dioxide[identifier]);
                            series28.add(new Second(new Date()), noise[identifier]);
                            dataset25.addSeries(series25);
                            dataset26.addSeries(series26);
                            dataset27.addSeries(series27);
                            dataset28.addSeries(series28);
                            break;
                        case 7:
                            series29.add(new Second(new Date()), humidity[identifier]);
                            series30.add(new Second(new Date()), temperature[identifier]);
                            series31.add(new Second(new Date()), dioxide[identifier]);
                            series32.add(new Second(new Date()), noise[identifier]);
                            dataset29.addSeries(series29);
                            dataset30.addSeries(series30);
                            dataset31.addSeries(series31);
                            dataset32.addSeries(series32);
                            break;
                        case 8:
                            series33.add(new Second(new Date()), humidity[identifier]);
                            series34.add(new Second(new Date()), temperature[identifier]);
                            series35.add(new Second(new Date()), dioxide[identifier]);
                            series36.add(new Second(new Date()), noise[identifier]);
                            dataset33.addSeries(series33);
                            dataset34.addSeries(series34);
                            dataset35.addSeries(series35);
                            dataset36.addSeries(series36);
                            break;
                        case 9:
                            series37.add(new Second(new Date()), humidity[identifier]);
                            series38.add(new Second(new Date()), temperature[identifier]);
                            series39.add(new Second(new Date()), dioxide[identifier]);
                            series40.add(new Second(new Date()), noise[identifier]);
                            dataset37.addSeries(series37);
                            dataset38.addSeries(series38);
                            dataset39.addSeries(series39);
                            dataset40.addSeries(series40);
                            break;
                        case 10:
                            series41.add(new Second(new Date()), humidity[identifier]);
                            series42.add(new Second(new Date()), temperature[identifier]);
                            series43.add(new Second(new Date()), dioxide[identifier]);
                            series44.add(new Second(new Date()), noise[identifier]);
                            dataset41.addSeries(series41);
                            dataset42.addSeries(series42);
                            dataset43.addSeries(series43);
                            dataset44.addSeries(series44);
                            break;
                        case 11:
                            series45.add(new Second(new Date()), humidity[identifier]);
                            series46.add(new Second(new Date()), temperature[identifier]);
                            series47.add(new Second(new Date()), dioxide[identifier]);
                            series48.add(new Second(new Date()), noise[identifier]);
                            dataset45.addSeries(series45);
                            dataset46.addSeries(series46);
                            dataset47.addSeries(series47);
                            dataset48.addSeries(series48);
                            break;
                        case 12:
                            series49.add(new Second(new Date()), humidity[identifier]);
                            series50.add(new Second(new Date()), temperature[identifier]);
                            series51.add(new Second(new Date()), dioxide[identifier]);
                            series52.add(new Second(new Date()), noise[identifier]);
                            dataset49.addSeries(series49);
                            dataset50.addSeries(series50);
                            dataset51.addSeries(series51);
                            dataset52.addSeries(series52);
                            break;
                        case 13:
                            series53.add(new Second(new Date()), humidity[identifier]);
                            series54.add(new Second(new Date()), temperature[identifier]);
                            series55.add(new Second(new Date()), dioxide[identifier]);
                            series56.add(new Second(new Date()), noise[identifier]);
                            dataset53.addSeries(series53);
                            dataset54.addSeries(series54);
                            dataset55.addSeries(series55);
                            dataset56.addSeries(series56);
                            break;
                        case 14:
                            series57.add(new Second(new Date()), humidity[identifier]);
                            series58.add(new Second(new Date()), temperature[identifier]);
                            series59.add(new Second(new Date()), dioxide[identifier]);
                            series60.add(new Second(new Date()), noise[identifier]);
                            dataset57.addSeries(series57);
                            dataset58.addSeries(series58);
                            dataset59.addSeries(series59);
                            dataset60.addSeries(series60);
                            break;
                        case 15:
                            series61.add(new Second(new Date()), humidity[identifier]);
                            series62.add(new Second(new Date()), temperature[identifier]);
                            series63.add(new Second(new Date()), dioxide[identifier]);
                            series64.add(new Second(new Date()), noise[identifier]);
                            dataset61.addSeries(series61);
                            dataset62.addSeries(series62);
                            dataset63.addSeries(series63);
                            dataset64.addSeries(series64);
                            break;
                        case 16:
                            series65.add(new Second(new Date()), humidity[identifier]);
                            series66.add(new Second(new Date()), temperature[identifier]);
                            series67.add(new Second(new Date()), dioxide[identifier]);
                            series68.add(new Second(new Date()), noise[identifier]);
                            dataset65.addSeries(series65);
                            dataset66.addSeries(series66);
                            dataset67.addSeries(series67);
                            dataset68.addSeries(series68);
                            break;
                        case 17:
                            series69.add(new Second(new Date()), humidity[identifier]);
                            series70.add(new Second(new Date()), temperature[identifier]);
                            series71.add(new Second(new Date()), dioxide[identifier]);
                            series72.add(new Second(new Date()), noise[identifier]);
                            dataset69.addSeries(series69);
                            dataset70.addSeries(series70);
                            dataset71.addSeries(series71);
                            dataset72.addSeries(series72);
                            break;
                        case 18:
                            series73.add(new Second(new Date()), humidity[identifier]);
                            series74.add(new Second(new Date()), temperature[identifier]);
                            series75.add(new Second(new Date()), dioxide[identifier]);
                            series76.add(new Second(new Date()), noise[identifier]);
                            dataset73.addSeries(series73);
                            dataset74.addSeries(series74);
                            dataset75.addSeries(series75);
                            dataset76.addSeries(series76);
                            break;
                        case 19:
                            series77.add(new Second(new Date()), humidity[identifier]);
                            series78.add(new Second(new Date()), temperature[identifier]);
                            series79.add(new Second(new Date()), dioxide[identifier]);
                            series80.add(new Second(new Date()), noise[identifier]);
                            dataset77.addSeries(series77);
                            dataset78.addSeries(series78);
                            dataset79.addSeries(series79);
                            dataset80.addSeries(series80);
                            break;
                        default:
                            break;
                    }
                });
                time.start();
            }
        });
    }

    public static void humidityChartInsert(TimeSeries _series, TimeSeriesCollection _dataset) throws InterruptedException {

        _dataset.addSeries(_series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Humedad Interior",
                "Tiempo (h)",
                "Humedad (%)",
                _dataset,
                false,
                false,
                false
        );
        // Mostramos la grafica dentro del HumidityPanel
        graphicpainter(chart, HumidityPanel);
    }

    public static void temperatureChartInsert(TimeSeries _series, TimeSeriesCollection _dataset) throws InterruptedException {

        _dataset.addSeries(_series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Temperatura Interior",
                "Tiempo (h)",
                "Grados (º)",
                _dataset,
                false,
                false,
                false
        );
        // Mostramos la grafica dentro del TemperaturePanel
        graphicpainter(chart, TemperaturePanel);
    }

    public static void dioxideChartInsert(TimeSeries _series, TimeSeriesCollection _dataset) throws InterruptedException {

        _dataset.addSeries(_series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Dioxido Interior",
                "Tiempo (h)",
                "Dioxido (ppm)",
                _dataset,
                false,
                false,
                false
        );
        // Mostramos la grafica dentro del DioxidePanel
        graphicpainter(chart, DioxidePanel);
    }

    public static void noiseChartInsert(TimeSeries _series, TimeSeriesCollection _dataset) throws InterruptedException {

        _dataset.addSeries(_series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Ruido Interior",
                "Tiempo (h)",
                "Decibelios (dB)",
                _dataset,
                false,
                false,
                false
        );
        // Mostramos la grafica dentro del NoisePanel
        graphicpainter(chart, NoisePanel);
    }

    public static void parametersInsert(int _humidity, int _temperature, int _dioxide, int _noise, int _preasure, int _luminosity, int _numPerson, int _fire) {

        if (fire[identifier] == 1) {
            flame = "Alerta de incendio";
        }
        processingParametersTable.setValueAt(_humidity, 0, 1);
        processingParametersTable.setValueAt(_temperature, 1, 1);
        processingParametersTable.setValueAt(_dioxide, 2, 1);
        processingParametersTable.setValueAt(_noise, 3, 1);
        processingParametersTable.setValueAt(_preasure, 4, 1);
        processingParametersTable.setValueAt(_luminosity, 5, 1);
        processingParametersTable.setValueAt(_numPerson, 6, 1);
        processingParametersTable.setValueAt(flame, 7, 1);

    }

    public static void graphicpainter(JFreeChart _chart, javax.swing.JPanel auxPanel) {
        // Mostramos la grafica dentro de los Paneles
        ChartPanel panel = new ChartPanel(_chart);
        auxPanel.setLayout(new java.awt.BorderLayout());
        auxPanel.add(panel);
        auxPanel.validate();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        leftPanel = new javax.swing.JPanel();
        GraphsPanel = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        HumidityPanel = new javax.swing.JPanel();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        TemperaturePanel = new javax.swing.JPanel();
        jLayeredPane3 = new javax.swing.JLayeredPane();
        DioxidePanel = new javax.swing.JPanel();
        jLayeredPane4 = new javax.swing.JLayeredPane();
        NoisePanel = new javax.swing.JPanel();
        rightPanel = new javax.swing.JPanel();
        TablePanel = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        parametersPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        processingParametersTable = new javax.swing.JTable();
        DataPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        IP = new javax.swing.JTextField();
        Port = new javax.swing.JTextField();
        Name = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        leftPanel.setMaximumSize(new java.awt.Dimension(252, 149));
        leftPanel.setLayout(new java.awt.GridBagLayout());

        GraphsPanel.setLayout(new java.awt.GridBagLayout());

        jLayeredPane1.setBorder(javax.swing.BorderFactory.createTitledBorder("Humedad"));
        jLayeredPane1.setLayout(new java.awt.GridBagLayout());

        HumidityPanel.setMaximumSize(new java.awt.Dimension(640, 420));
        HumidityPanel.setMinimumSize(new java.awt.Dimension(640, 420));
        HumidityPanel.setPreferredSize(new java.awt.Dimension(640, 420));
        HumidityPanel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jLayeredPane1.add(HumidityPanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 1.0;
        GraphsPanel.add(jLayeredPane1, gridBagConstraints);

        jLayeredPane2.setBorder(javax.swing.BorderFactory.createTitledBorder("Temperatura"));
        jLayeredPane2.setLayout(new java.awt.GridBagLayout());

        TemperaturePanel.setMaximumSize(new java.awt.Dimension(640, 420));
        TemperaturePanel.setMinimumSize(new java.awt.Dimension(640, 420));
        TemperaturePanel.setPreferredSize(new java.awt.Dimension(640, 420));
        TemperaturePanel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jLayeredPane2.add(TemperaturePanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 1.0;
        GraphsPanel.add(jLayeredPane2, gridBagConstraints);

        jLayeredPane3.setBorder(javax.swing.BorderFactory.createTitledBorder("Dioxido Carbono"));
        jLayeredPane3.setLayout(new java.awt.GridBagLayout());

        DioxidePanel.setMaximumSize(new java.awt.Dimension(640, 420));
        DioxidePanel.setMinimumSize(new java.awt.Dimension(640, 420));
        DioxidePanel.setPreferredSize(new java.awt.Dimension(640, 420));
        DioxidePanel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jLayeredPane3.add(DioxidePanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 1.0;
        GraphsPanel.add(jLayeredPane3, gridBagConstraints);

        jLayeredPane4.setBorder(javax.swing.BorderFactory.createTitledBorder("Ruido"));
        jLayeredPane4.setLayout(new java.awt.GridBagLayout());

        NoisePanel.setMaximumSize(new java.awt.Dimension(640, 420));
        NoisePanel.setMinimumSize(new java.awt.Dimension(640, 420));
        NoisePanel.setPreferredSize(new java.awt.Dimension(640, 420));
        NoisePanel.setLayout(new java.awt.GridBagLayout());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jLayeredPane4.add(NoisePanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 1.0;
        GraphsPanel.add(jLayeredPane4, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.9;
        leftPanel.add(GraphsPanel, gridBagConstraints);

        rightPanel.setMaximumSize(new java.awt.Dimension(450, 100));
        rightPanel.setLayout(new java.awt.GridBagLayout());

        TablePanel.setLayout(new java.awt.GridBagLayout());

        jPanel4.setLayout(new java.awt.GridBagLayout());

        parametersPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Parámetros"));
        parametersPanel.setLayout(new java.awt.GridBagLayout());

        jScrollPane1.setMinimumSize(new java.awt.Dimension(300, 300));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(122, 122));

        processingParametersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"HUMEDAD", null},
                {"TEMPERATURA", null},
                {"DIOXIDO CARBONO", null},
                {"NIVEL RUIDO", null},
                {"PRESIÓN ATM.", null},
                {"LUMINOSIDAD", null},
                {"NÚMERO PERSONAS", null},
                {"INCENDIO", null},
                {null, null},
                {"SALA MOSTRADA", null},
                {null, null},
                {"NOMBRE", "ÁLVARO"},
                {"APELLIDO 1", "CABAÑAS"},
                {"APELLIDO 2", "SÁNCHEZ"},
                {"CURSO", "2 º STI"}
            },
            new String [] {
                "Parámetro", "Valor"
            }
        ));
        processingParametersTable.setRowHeight(40);
        processingParametersTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(processingParametersTable);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        parametersPanel.add(jScrollPane1, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.2;
        jPanel4.add(parametersPanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.3;
        TablePanel.add(jPanel4, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.8;
        rightPanel.add(TablePanel, gridBagConstraints);

        DataPanel.setMaximumSize(new java.awt.Dimension(450, 100));
        DataPanel.setMinimumSize(new java.awt.Dimension(450, 100));
        DataPanel.setLayout(new java.awt.GridBagLayout());

        jLabel1.setText("Añadir Módulo:");
        jLabel1.setToolTipText("");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        DataPanel.add(jLabel1, gridBagConstraints);

        IP.setText("Insert IP");
        IP.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        IP.setMaximumSize(new java.awt.Dimension(30, 24));
        IP.setMinimumSize(new java.awt.Dimension(30, 24));
        IP.setName(""); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 5);
        DataPanel.add(IP, gridBagConstraints);

        Port.setText("Insert Port");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 5);
        DataPanel.add(Port, gridBagConstraints);

        Name.setText("Name");
        Name.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Name.setMaximumSize(new java.awt.Dimension(30, 24));
        Name.setMinimumSize(new java.awt.Dimension(30, 24));
        Name.setName(""); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 5);
        DataPanel.add(Name, gridBagConstraints);

        jButton1.setText("Accept");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        DataPanel.add(jButton1, new java.awt.GridBagConstraints());

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.05;
        rightPanel.add(DataPanel, gridBagConstraints);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1515, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(leftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1147, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 368, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addGap(0, 1149, Short.MAX_VALUE)
                    .addComponent(rightPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 765, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(leftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 765, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(rightPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 765, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String ip, port, name;

        ip = IP.getText();
        port = Port.getText();
        name = Name.getText();

        counter++;
        first.stop();

        try {
            humidityChartInsert(seriesaux1, datasetaux1);
            temperatureChartInsert(seriesaux2, datasetaux2);
            dioxideChartInsert(seriesaux3, datasetaux3);
            noiseChartInsert(seriesaux4, datasetaux4);
        } catch (InterruptedException ex) {
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            NewJFrame.JavaTCPconnection(ip, port, name);
        } catch (IOException ex) {
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

        Timer second = new Timer(60000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                int id = 0;
                int aux = 0;

                switch (id) {
                    case 0:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            dataset1.addSeries(series1);
                            dataset2.addSeries(series2);
                            dataset3.addSeries(series3);
                            dataset4.addSeries(series4);
                            try {
                                humidityChartInsert(series1, dataset1);
                                temperatureChartInsert(series2, dataset2);
                                dioxideChartInsert(series3, dataset3);
                                noiseChartInsert(series4, dataset4);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            aux++;
                        }   break;
                    case 1:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            dataset5.addSeries(series5);
                            dataset6.addSeries(series6);
                            dataset7.addSeries(series7);
                            dataset8.addSeries(series8);
                            try {
                                humidityChartInsert(series5, dataset5);
                                temperatureChartInsert(series6, dataset6);
                                dioxideChartInsert(series7, dataset7);
                                noiseChartInsert(series8, dataset8);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 2:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series9, dataset9);
                                temperatureChartInsert(series10, dataset10);
                                dioxideChartInsert(series11, dataset11);
                                noiseChartInsert(series12, dataset12);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 3:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series13, dataset13);
                                temperatureChartInsert(series14, dataset14);
                                dioxideChartInsert(series15, dataset15);
                                noiseChartInsert(series16, dataset16);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 4:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series17, dataset17);
                                temperatureChartInsert(series18, dataset18);
                                dioxideChartInsert(series19, dataset19);
                                noiseChartInsert(series20, dataset20);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 5:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series21, dataset21);
                                temperatureChartInsert(series22, dataset22);
                                dioxideChartInsert(series23, dataset23);
                                noiseChartInsert(series24, dataset24);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 6:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series25, dataset25);
                                temperatureChartInsert(series26, dataset26);
                                dioxideChartInsert(series27, dataset27);
                                noiseChartInsert(series28, dataset28);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 7:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series29, dataset29);
                                temperatureChartInsert(series30, dataset30);
                                dioxideChartInsert(series31, dataset31);
                                noiseChartInsert(series32, dataset32);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 8:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series33, dataset33);
                                temperatureChartInsert(series34, dataset34);
                                dioxideChartInsert(series35, dataset35);
                                noiseChartInsert(series36, dataset36);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 9:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series37, dataset37);
                                temperatureChartInsert(series38, dataset38);
                                dioxideChartInsert(series39, dataset39);
                                noiseChartInsert(series40, dataset40);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 10:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series41, dataset41);
                                temperatureChartInsert(series42, dataset42);
                                dioxideChartInsert(series43, dataset43);
                                noiseChartInsert(series44, dataset44);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 11:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series45, dataset45);
                                temperatureChartInsert(series46, dataset46);
                                dioxideChartInsert(series47, dataset47);
                                noiseChartInsert(series48, dataset48);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 12:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series49, dataset49);
                                temperatureChartInsert(series50, dataset50);
                                dioxideChartInsert(series51, dataset51);
                                noiseChartInsert(series52, dataset52);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 13:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series53, dataset53);
                                temperatureChartInsert(series54, dataset54);
                                dioxideChartInsert(series55, dataset55);
                                noiseChartInsert(series56, dataset56);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 14:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series57, dataset57);
                                temperatureChartInsert(series58, dataset58);
                                dioxideChartInsert(series59, dataset59);
                                noiseChartInsert(series60, dataset60);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 15:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series61, dataset61);
                                temperatureChartInsert(series62, dataset62);
                                dioxideChartInsert(series63, dataset63);
                                noiseChartInsert(series64, dataset64);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 16:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series65, dataset65);
                                temperatureChartInsert(series66, dataset66);
                                dioxideChartInsert(series67, dataset67);
                                noiseChartInsert(series68, dataset68);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 17:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series69, dataset69);
                                temperatureChartInsert(series70, dataset70);
                                dioxideChartInsert(series71, dataset71);
                                noiseChartInsert(series72, dataset72);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 18:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series73, dataset73);
                                temperatureChartInsert(series74, dataset74);
                                dioxideChartInsert(series75, dataset75);
                                noiseChartInsert(series76, dataset76);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    case 19:
                        processingParametersTable.setValueAt(id, 9, 1);
                        while (aux < 15) {
                            try {
                                humidityChartInsert(series77, dataset77);
                                temperatureChartInsert(series78, dataset78);
                                dioxideChartInsert(series79, dataset79);
                                noiseChartInsert(series80, dataset80);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            parametersInsert(
                                    humidity[id],
                                    temperature[id],
                                    dioxide[id],
                                    noise[id],
                                    preasure[id],
                                    luminosity[id],
                                    numPerson[id],
                                    fire[id]
                            );
                            
                            try {
                                Thread.sleep(4000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            if (id == counter) {
                                id = 0;
                            }
                            aux++;
                        }   break;
                    default:
                        break;
                }
                id++;
            }
        });
        second.start();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String args[]) throws IOException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                //Inicia la interfaz gráfica
                new NewJFrame().setVisible(true);

                //Inicia la conexión TCP/IP
                NewJFrame.JavaTCPconnection("172.26.240.240", "8080", "Soy el cliente y me he conectado correctamente!");
            } catch (InterruptedException | ArduinoException | IOException | ClassNotFoundException ex) {
                Logger.getLogger(NewJFrame.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel DataPanel;
    private static javax.swing.JPanel DioxidePanel;
    private javax.swing.JPanel GraphsPanel;
    private static javax.swing.JPanel HumidityPanel;
    private javax.swing.JTextField IP;
    private javax.swing.JTextField Name;
    private static javax.swing.JPanel NoisePanel;
    private javax.swing.JTextField Port;
    private javax.swing.JPanel TablePanel;
    private static javax.swing.JPanel TemperaturePanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JLayeredPane jLayeredPane3;
    private javax.swing.JLayeredPane jLayeredPane4;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JPanel parametersPanel;
    private static javax.swing.JTable processingParametersTable;
    private javax.swing.JPanel rightPanel;
    // End of variables declaration//GEN-END:variables
}
